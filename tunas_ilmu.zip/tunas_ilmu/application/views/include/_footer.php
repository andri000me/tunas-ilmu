<div class="footer">
	
	<div class="footer-inner">
		
		<div class="container">
			
			<div class="row">
				
    			<div class="span12">
    				&copy; <?php echo date('Y');?> <a href="#">Pondok Pesantren Tunas Ilmu</a>.
    			</div> <!-- /span12 -->
    			
    		</div> <!-- /row -->
    		
		</div> <!-- /container -->
		
	</div> <!-- /footer-inner -->
	
</div> <!-- /footer -->
    


<script src="<?php echo config_item('js'); ?>jquery-1.7.2.min.js"></script>
	
<script src="<?php echo config_item('js'); ?>bootstrap.js"></script>
<script src="<?php echo config_item('js'); ?>base.js"></script>


  </body>

</html>