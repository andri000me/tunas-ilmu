<div class="footer">
	
	<div class="footer-inner">
		
		<div class="container">
			
			<div class="row">
				
    			<div class="span12">
    				&copy; <?php echo date('Y');?> <a href="#">Pendaftaran Santri Tunas Ilmu</a>.
    			</div> <!-- /span12 -->
    			
    		</div> <!-- /row -->
    		
		</div> <!-- /container -->
		
	</div> <!-- /footer-inner -->
	
</div> <!-- /footer -->

<script src="<?php echo config_item('js') ?>jquery-1.7.2.min.js"></script>
<script src="<?php echo config_item('js') ?>bootstrap.js"></script>
<script src="<?php echo config_item('js') ?>signin.js"></script>
<script src="<?php echo config_item('js') ?>excanvas.min.js"></script> 
<script src="<?php echo config_item('js') ?>chart.min.js" type="text/javascript"></script> 
<script language="javascript" type="text/javascript" src="<?php echo config_item('js') ?>full-calendar/fullcalendar.min.js"></script>
<script src="<?php echo config_item('js') ?>base.js"></script>

</body>

</html>