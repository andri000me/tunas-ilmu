<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>
<?php $this->load->view('include/subnavbar'); ?>

<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	
	      <div class="row">	      	
	      	
	      	<div class="span12">
	      		
	      		<div id="target-1" class="widget">
	      			
	      			<div class="widget-content">
	      				
			      		<h1>12 Columns</h1>
			      		 
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		</div> <!-- /span12 -->
	      	
	      </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div> <!-- /main -->

<?php $this->load->view('include/footer') ?>